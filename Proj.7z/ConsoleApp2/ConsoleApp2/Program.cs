﻿using System;
using Discord;
using Discord.WebSocket;
using System.Threading.Tasks;
using System.Net;
using System.IO;


namespace ConsoleApp2
{
    class Program
    {
        BotClass bot = new BotClass("ODkwMjkwMjE4ODc4NTI5NTY3.YUtpYA.ZHTabksjkvq56epA6HsklobucMo");
        static void Main(string[] args)
        {
            new Program().bot.MainAsync().GetAwaiter().GetResult();
        }
    }
}
