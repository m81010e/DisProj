﻿using System;
using System.Threading.Tasks;
using Discord;
using Discord.WebSocket;
using Project.Bot;

// "ODkwMjkwMjE4ODc4NTI5NTY3.YUtpYA.ZHTabksjkvq56epA6HsklobucMo"

/// <summary>
/// Класс Bot реализует запуск бота на сервере и обработку его команд
/// </summary>
public class BotClass
{
    private DiscordSocketClient client;
    private string _token;
    private CommandsFabric CommandsFabric;

    public BotClass(string token)
	{
       _token = token;
	}

    /// <summary>
    /// Метод запускает бота с обработчиком команд
    /// </summary>
    /// <returns></returns>
	public async Task MainAsync()
        {
            CommandsFabric = new CommandsFabric();
            client = new DiscordSocketClient();
            client.MessageReceived += CommandsHandler;

            await client.LoginAsync(TokenType.Bot, _token);
            await client.StartAsync();

            Console.ReadLine();
        }

        /// <summary>
        ///  Обработчик команд
        /// </summary>
        /// <param name="msg"></param>
        /// <returns></returns>
        private Task CommandsHandler(SocketMessage msg)
        {
            if (!msg.Author.IsBot)
            {
                msg.Channel.SendMessageAsync(CommandsFabric.GetCommand(msg.Content, msg));
            }
            return Task.CompletedTask;
        }
        

        
        private void Name() 
        {
            System.Net.WebRequest reqGET = System.Net.WebRequest.Create(@"https://localhost:5001/cmd/try");
            System.Net.WebResponse resp = reqGET.GetResponse();
            System.IO.Stream stream = resp.GetResponseStream();
            System.IO.StreamReader sr = new System.IO.StreamReader(stream);
            string s = sr.ReadToEnd();
            Console.WriteLine(s);
        }
}
