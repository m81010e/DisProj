﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Linq;

namespace ConsoleApp2.Bot
{
    class OWParser
    {
        public OWParser() {
        
        }
        public static Dictionary<string, string> Parse(string platform, string player)
        {
            var url = $"https://playoverwatch.com/ru-ru/career/{platform}/{player}/";
            HttpClientHandler handler = new HttpClientHandler();

            var client = new HttpClient(handler);
            HttpResponseMessage response = client.GetAsync(url).Result;

            var html = response.Content.ReadAsStringAsync().Result;
            HtmlAgilityPack.HtmlDocument document = new HtmlAgilityPack.HtmlDocument();
            document.LoadHtml(html);

            try
            {
                var points = document.DocumentNode.SelectNodes("//div[@class='competitive-rank-level']").Select(x => x.InnerText).ToList();
                var roles = document.DocumentNode.SelectNodes("//div[@class='competitive-rank-tier competitive-rank-tier-tooltip']|" +
                    "//div[@class='competitive-rank-tier " +
                    "competitive-rank-tier-tooltip competitive-rank-tier--highest']").Select(x => x.Attributes["data-ow-tooltip-text"].Value.ToString()).ToList();
                Dictionary<string, string> rating = new Dictionary<string, string>();
                var temp = points.Count;
                for (int i = 0; i < temp; i++)
                {
                    if (!rating.ContainsKey(roles[i]))
                    {
                        rating.Add(roles[i], points[i]);
                    }
                }
                return rating;
            }
            catch (ArgumentNullException exception)
            {
                return new Dictionary<string, string>();
            }
        }
    }
}
