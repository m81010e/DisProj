﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Bot
{
    /// <summary>
    /// Абстрактный класс для реализации команд
    /// </summary>
    public abstract class BotCommand
    {
        /// <summary>
        /// Реализация метода находится в наследниках
        /// </summary>
        /// <returns></returns>
        public abstract string Execute();

        public abstract string ExecuteWithParams(int num);

        public abstract string ExecuteWithTwoStringParams(string platform, string id);
    }
}
