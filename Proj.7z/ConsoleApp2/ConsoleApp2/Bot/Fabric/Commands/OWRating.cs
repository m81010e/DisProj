﻿using ConsoleApp2.Bot;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Project.Bot
{
    class OWRating : BotCommand
    {
        public string result = "";
        public override string Execute()
        {
            throw new NotImplementedException();
        }

        public override string ExecuteWithParams(int num)
        {
            throw new NotImplementedException();
        }

        public override string ExecuteWithTwoStringParams(string platform, string id)
        {

            foreach (KeyValuePair<string, string> keyValue in OWParser.Parse(platform, id))
            {
                result += $"{keyValue.Key} = {keyValue.Value} \n";
            }
            return result;
        }
    }
}
