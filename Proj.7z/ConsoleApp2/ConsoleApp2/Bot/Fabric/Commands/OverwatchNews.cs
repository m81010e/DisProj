﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Bot
{
    public class OverwatchNews : BotCommand
    {
        /// <summary>
        /// Возвращает результат парсинга (ссылку на новость) страницы по новостям Overwatch 
        /// </summary>
        /// <returns></returns>
        public override string Execute()
        {
            throw new NotImplementedException();
        }
        public override string ExecuteWithParams(int num)
        {
            throw new NotImplementedException();
        }

        public override string ExecuteWithTwoStringParams(string platform, string id)
        {
            throw new NotImplementedException();
        }
    }
}
