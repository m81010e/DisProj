﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Bot
{
    public class Roll : BotCommand
    {
        /// <summary>
        /// Возвращает случайное число в указанном диапазоне
        /// </summary>
        /// <returns></returns>
        public override string Execute()
        {
            return Convert.ToString(new Random().Next(0, 100), 10);
        }
        public override string ExecuteWithParams(int num = 100)
        {
            return Convert.ToString(new Random().Next(0, num), 10); ;
        }

        public override string ExecuteWithTwoStringParams(string platform, string id)
        {
            throw new NotImplementedException();
        }
    }
}