﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2.Methods
{
    class ParsersGenerals
    {
        string URL;
        ParsersGenerals(string URL) 
        {
            this.URL = new string(URL);

        }
    }
}
