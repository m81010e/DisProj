﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp2.Methods
{
    public interface Parser
    {
        
    }
}
