﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Bot
{
    public class Dota2News : BotCommand
    {
        public override string Execute()
        {
            throw new NotImplementedException();
        }
    }
}
