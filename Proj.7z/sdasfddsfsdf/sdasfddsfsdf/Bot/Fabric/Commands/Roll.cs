﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Bot
{
    public class Roll : BotCommand
    {
        public override string Execute()
        {
            return Convert.ToString(new Random().Next(0, 100), 10);
        }

    }
}