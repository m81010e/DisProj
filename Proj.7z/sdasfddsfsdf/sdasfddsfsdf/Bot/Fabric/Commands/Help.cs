﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project.Bot
{
    public class Help : BotCommand
    {
        public override string Execute()
        {
            return "Команды доступные боту: \n" +
                "_help - выводит команды бота \n" +
                "_roll - генерирует случайное число от 0 до 100 \n" +
                "_8ball - получите ответ на ваш вопрос \n" +
                "_dota2_news - случайная новость про D2";

        }
    }
}
