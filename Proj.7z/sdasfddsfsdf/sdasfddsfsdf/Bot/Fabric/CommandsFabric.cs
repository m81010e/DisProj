﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Discord.WebSocket;
using Discord;

namespace Project.Bot
{
    public class CommandsFabric
    {
        public string GetCommand(string cmd, SocketMessage m)
        {
            string[] msg = cmd.Split(' ');
            switch (msg[0])
            {
                case "_help": return new Help().Execute();
                case "_roll": return new Roll().Execute();
                case "_8ball": return new EightBall().Execute();
                case "_dota2_news": return new Dota2News().Execute();
                case "_over_news": return new OverwatchNews().Execute();
                case "_delete": 
                     
                    break;
                 
            }

           

            return null;
        }

        


       
    }
}
