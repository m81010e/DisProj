using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Discord;
using Discord.WebSocket;
using System.Net;
using System.IO;

namespace sdasfddsfsdf
{
    public class Program
    {

        Bot bot = new Bot("ODkwMjkwMjE4ODc4NTI5NTY3.YUtpYA.ZHTabksjkvq56epA6HsklobucMo");

        public static void Main(string[] args)
        {
       
            CreateHostBuilder(args).Build().Run();
            
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>();
                });

       
    }
}
